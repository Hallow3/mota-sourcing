/**
 * Production environment configuration.
 */
export const environment = {
  production: true,
  apiUrl: 'http://localhost:8085/api'
};
